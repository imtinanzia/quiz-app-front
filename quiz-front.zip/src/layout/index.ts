export { default as MainLayout } from './main-layout';
